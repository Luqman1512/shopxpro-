export type UserRole = 'customer' | 'seller' | 'admin';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  phone?: string;
  avatar?: string;
  createdAt: string;
}

export interface Seller {
  id: string;
  userId: string;
  shopName: string;
  shopLogo?: string;
  shopBanner?: string;
  description?: string;
  verified: boolean;
  rating: number;
  totalSales: number;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  parentId?: string;
  image?: string;
}

export interface ProductVariant {
  id: string;
  productId: string;
  sku: string;
  options: Record<string, string>; // e.g., { size: 'M', color: 'Red' }
  price: number;
  stock: number;
}

export interface Product {
  id: string;
  sellerId: string;
  categoryId: string;
  title: string;
  description: string;
  price: number;
  discount?: number;
  sku: string;
  stock: number;
  images: string[];
  rating: number;
  reviewCount: number;
  sold: number;
  variants?: ProductVariant[];
  attributes?: Record<string, any>;
  createdAt: string;
}

export interface CartItem {
  id: string;
  productId: string;
  variantId?: string;
  quantity: number;
  product: Product;
  variant?: ProductVariant;
}

export interface Address {
  id: string;
  userId: string;
  name: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  postcode: string;
  isDefault: boolean;
}

export type OrderStatus = 'placed' | 'packed' | 'shipped' | 'hub_arrived' | 'out_for_delivery' | 'delivered' | 'cancelled';
export type PaymentMethod = 'fpx' | 'credit_card' | 'cod' | 'wallet';
export type PaymentStatus = 'pending' | 'paid' | 'failed' | 'refunded';

export interface Order {
  id: string;
  userId: string;
  sellerId: string;
  total: number;
  subtotal: number;
  shippingFee: number;
  discount: number;
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  trackingNumber: string;
  shippingAddress: Address;
  items: OrderItem[];
  createdAt: string;
  updatedAt: string;
}

export interface OrderItem {
  id: string;
  orderId: string;
  productId: string;
  variantId?: string;
  quantity: number;
  price: number;
  product: Product;
  variant?: ProductVariant;
}

export interface Review {
  id: string;
  productId: string;
  userId: string;
  orderId: string;
  rating: number;
  comment: string;
  images: string[];
  verifiedPurchase: boolean;
  createdAt: string;
  user: User;
}

export interface Voucher {
  id: string;
  code: string;
  type: 'percentage' | 'fixed';
  discountValue: number;
  minSpend: number;
  maxDiscount?: number;
  expiryDate: string;
  usageLimit: number;
  usageCount: number;
  sellerId?: string;
}

export interface Wallet {
  id: string;
  userId: string;
  balance: number;
}

export interface WalletTransaction {
  id: string;
  walletId: string;
  type: 'topup' | 'payment' | 'refund' | 'withdrawal';
  amount: number;
  description: string;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: string;
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}

export interface ShippingEvent {
  id: string;
  trackingNumber: string;
  status: OrderStatus;
  location: string;
  timestamp: string;
}
