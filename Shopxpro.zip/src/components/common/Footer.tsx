import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container mx-auto px-4 py-8 md:py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {/* About */}
          <div>
            <div className="flex items-center gap-2 mb-3 md:mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">S</span>
              </div>
              <h3 className="text-white font-semibold text-base md:text-lg">
                SHOPX <span className="text-orange-500">PRO</span>
              </h3>
            </div>
            <p className="text-xs md:text-sm mb-3 md:mb-4">
              Your trusted e-commerce marketplace for quality products at great prices.
            </p>
            <div className="flex gap-3 md:gap-4">
              <a href="#" className="hover:text-orange-500 transition-colors">
                <Facebook className="w-4 h-4 md:w-5 md:h-5" />
              </a>
              <a href="#" className="hover:text-orange-500 transition-colors">
                <Twitter className="w-4 h-4 md:w-5 md:h-5" />
              </a>
              <a href="#" className="hover:text-orange-500 transition-colors">
                <Instagram className="w-4 h-4 md:w-5 md:h-5" />
              </a>
              <a href="#" className="hover:text-orange-500 transition-colors">
                <Youtube className="w-4 h-4 md:w-5 md:h-5" />
              </a>
            </div>
          </div>

          {/* Customer Service */}
          <div>
            <h3 className="text-white font-semibold text-base md:text-lg mb-3 md:mb-4">Customer Service</h3>
            <ul className="space-y-1.5 md:space-y-2 text-xs md:text-sm">
              <li>
                <Link to="/help" className="hover:text-orange-500 transition-colors">
                  Help Center
                </Link>
              </li>
              <li>
                <Link to="/shipping" className="hover:text-orange-500 transition-colors">
                  Shipping Info
                </Link>
              </li>
              <li>
                <Link to="/returns" className="hover:text-orange-500 transition-colors">
                  Returns & Refunds
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-orange-500 transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold text-base md:text-lg mb-3 md:mb-4">Quick Links</h3>
            <ul className="space-y-1.5 md:space-y-2 text-xs md:text-sm">
              <li>
                <Link to="/about" className="hover:text-orange-500 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/careers" className="hover:text-orange-500 transition-colors">
                  Careers
                </Link>
              </li>
              <li>
                <Link to="/seller" className="hover:text-orange-500 transition-colors">
                  Become a Seller
                </Link>
              </li>
              <li>
                <Link to="/terms" className="hover:text-orange-500 transition-colors">
                  Terms & Conditions
                </Link>
              </li>
            </ul>
          </div>

          {/* Payment & Delivery */}
          <div>
            <h3 className="text-white font-semibold text-base md:text-lg mb-3 md:mb-4">Payment & Delivery</h3>
            <p className="text-xs md:text-sm mb-3 md:mb-4">We accept:</p>
            <div className="flex flex-wrap gap-2">
              <div className="bg-white px-2 md:px-3 py-1 rounded text-xs font-semibold text-gray-900">
                FPX
              </div>
              <div className="bg-white px-2 md:px-3 py-1 rounded text-xs font-semibold text-gray-900">
                VISA
              </div>
              <div className="bg-white px-2 md:px-3 py-1 rounded text-xs font-semibold text-gray-900">
                Mastercard
              </div>
              <div className="bg-white px-2 md:px-3 py-1 rounded text-xs font-semibold text-gray-900">
                COD
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-6 md:mt-8 pt-6 md:pt-8 text-center text-xs md:text-sm">
          <p>&copy; {new Date().getFullYear()} SHOPX PRO. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}