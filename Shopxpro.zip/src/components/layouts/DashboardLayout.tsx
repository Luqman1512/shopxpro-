import { Outlet, Link, useLocation } from 'react-router-dom';
import { Home, Package, ShoppingCart, Heart, Wallet, User, Settings, LogOut } from 'lucide-react';
import { useAuthStore } from '@/store';

export default function DashboardLayout() {
  const location = useLocation();
  const { user, logout } = useAuthStore();

  const getNavItems = () => {
    if (user?.role === 'customer') {
      return [
        { path: '/customer', icon: Home, label: 'Dashboard' },
        { path: '/customer/orders', icon: ShoppingCart, label: 'Orders' },
        { path: '/customer/wishlist', icon: Heart, label: 'Wishlist' },
        { path: '/customer/wallet', icon: Wallet, label: 'Wallet' },
        { path: '/customer/profile', icon: User, label: 'Profile' },
      ];
    }
    if (user?.role === 'seller') {
      return [
        { path: '/seller', icon: Home, label: 'Dashboard' },
        { path: '/seller/products', icon: Package, label: 'Products' },
        { path: '/seller/orders', icon: ShoppingCart, label: 'Orders' },
        { path: '/seller/shop', icon: Settings, label: 'Shop Settings' },
      ];
    }
    if (user?.role === 'admin') {
      return [
        { path: '/admin', icon: Home, label: 'Dashboard' },
        { path: '/admin/users', icon: User, label: 'Users' },
        { path: '/admin/categories', icon: Package, label: 'Categories' },
      ];
    }
    return [];
  };

  const navItems = getNavItems();

  return (
    <div className="min-h-screen flex bg-gray-50">
      <aside className="w-64 bg-white border-r border-gray-200">
        <div className="p-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">S</span>
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-800">SHOPX <span className="text-orange-600">PRO</span></h2>
              <p className="text-xs text-gray-500 capitalize">{user?.role} Panel</p>
            </div>
          </div>
        </div>
        <nav className="px-4 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            );
          })}
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Logout</span>
          </button>
        </nav>
      </aside>
      <main className="flex-1 p-8">
        <Outlet />
      </main>
    </div>
  );
}
