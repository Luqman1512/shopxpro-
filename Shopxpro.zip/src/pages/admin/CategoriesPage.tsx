export default function AdminCategoriesPage() {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h1 className="text-2xl font-bold mb-6">Category Management</h1>
      <p className="text-gray-600">Category management page coming soon...</p>
    </div>
  );
}
