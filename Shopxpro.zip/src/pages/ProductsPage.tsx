import React, { useState, useMemo } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { mockProducts, mockCategories } from '@/lib/mockData';
import { Star, SlidersHorizontal } from 'lucide-react';

export default function ProductsPage() {
  const [searchParams] = useSearchParams();
  const categorySlug = searchParams.get('category');
  const searchQuery = searchParams.get('search');

  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [minRating, setMinRating] = useState(0);
  const [sortBy, setSortBy] = useState('popular');

  const filteredProducts = useMemo(() => {
    let filtered = [...mockProducts];

    // Filter by category
    if (categorySlug) {
      const category = mockCategories.find((c) => c.slug === categorySlug);
      if (category) {
        filtered = filtered.filter((p) => p.categoryId === category.id);
      }
    }

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter((p) =>
        p.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filter by price range
    filtered = filtered.filter((p) => {
      const price = p.discount ? p.price * (1 - p.discount / 100) : p.price;
      return price >= priceRange[0] && price <= priceRange[1];
    });

    // Filter by rating
    filtered = filtered.filter((p) => p.rating >= minRating);

    // Sort
    if (sortBy === 'price-low') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-high') {
      filtered.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      filtered.sort((a, b) => b.rating - a.rating);
    } else {
      filtered.sort((a, b) => b.sold - a.sold);
    }

    return filtered;
  }, [categorySlug, searchQuery, priceRange, minRating, sortBy]);

  const currentCategory = categorySlug
    ? mockCategories.find((c) => c.slug === categorySlug)
    : null;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex gap-8">
        {/* Filters Sidebar */}
        <aside className="w-64 flex-shrink-0">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-6">
                <SlidersHorizontal className="w-5 h-5" />
                <h2 className="text-lg font-semibold">Filters</h2>
              </div>

              {/* Categories */}
              <div className="mb-6">
                <h3 className="font-medium mb-3">Categories</h3>
                <div className="space-y-2">
                  <Link
                    to="/products"
                    className={`block text-sm hover:text-orange-600 ${
                      !categorySlug ? 'text-orange-600 font-medium' : ''
                    }`}
                  >
                    All Products
                  </Link>
                  {mockCategories.map((category) => (
                    <Link
                      key={category.id}
                      to={`/products?category=${category.slug}`}
                      className={`block text-sm hover:text-orange-600 ${
                        categorySlug === category.slug ? 'text-orange-600 font-medium' : ''
                      }`}
                    >
                      {category.name}
                    </Link>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <h3 className="font-medium mb-3">Price Range</h3>
                <Slider
                  value={priceRange}
                  onValueChange={setPriceRange}
                  max={1000}
                  step={10}
                  className="mb-2"
                />
                <div className="flex items-center justify-between text-sm text-gray-600">
                  <span>RM {priceRange[0]}</span>
                  <span>RM {priceRange[1]}</span>
                </div>
              </div>

              {/* Rating */}
              <div className="mb-6">
                <h3 className="font-medium mb-3">Minimum Rating</h3>
                <div className="space-y-2">
                  {[4, 3, 2, 1].map((rating) => (
                    <button
                      key={rating}
                      onClick={() => setMinRating(rating)}
                      className={`flex items-center gap-2 text-sm w-full hover:text-orange-600 ${
                        minRating === rating ? 'text-orange-600 font-medium' : ''
                      }`}
                    >
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span>{rating}+ Stars</span>
                    </button>
                  ))}
                  <button
                    onClick={() => setMinRating(0)}
                    className={`text-sm hover:text-orange-600 ${
                      minRating === 0 ? 'text-orange-600 font-medium' : ''
                    }`}
                  >
                    All Ratings
                  </button>
                </div>
              </div>
            </CardContent>
          </Card>
        </aside>

        {/* Products Grid */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold">
                {currentCategory ? currentCategory.name : searchQuery ? `Search: "${searchQuery}"` : 'All Products'}
              </h1>
              <p className="text-gray-600 mt-1">{filteredProducts.length} products found</p>
            </div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="border border-gray-300 rounded-lg px-4 py-2"
            >
              <option value="popular">Most Popular</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="rating">Highest Rated</option>
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <Link key={product.id} to={`/products/${product.id}`}>
                <Card className="overflow-hidden hover:shadow-lg transition-shadow h-full">
                  <CardContent className="p-0">
                    <div className="aspect-square relative overflow-hidden">
                      <img
                        src={product.images[0]}
                        alt={product.title}
                        className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                      />
                      {product.discount && (
                        <Badge className="absolute top-2 right-2 bg-red-500">
                          -{product.discount}%
                        </Badge>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
                        {product.title}
                      </h3>
                      <div className="flex items-center gap-1 mb-2">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{product.rating}</span>
                        <span className="text-sm text-gray-500">({product.reviewCount})</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {product.discount ? (
                          <>
                            <span className="text-xl font-bold text-orange-600">
                              RM {(product.price * (1 - product.discount / 100)).toFixed(2)}
                            </span>
                            <span className="text-sm text-gray-500 line-through">
                              RM {product.price.toFixed(2)}
                            </span>
                          </>
                        ) : (
                          <span className="text-xl font-bold text-orange-600">
                            RM {product.price.toFixed(2)}
                          </span>
                        )}
                      </div>
                      <div className="mt-2 text-sm text-gray-500">
                        {product.sold} sold
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">No products found</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
