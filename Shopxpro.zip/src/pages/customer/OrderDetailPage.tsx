import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Package, Truck, MapPin, CreditCard, CheckCircle } from 'lucide-react';

export default function OrderDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();

  // Mock order data
  const order = {
    id: id || 'ORD-001',
    date: '2024-01-20',
    total: 299.99,
    subtotal: 254.99,
    shipping: 10.00,
    discount: 0,
    status: 'delivered',
    trackingNumber: 'SHXMY123456',
    paymentMethod: 'Credit Card',
    shippingAddress: {
      name: 'John Doe',
      phone: '+60123456789',
      address: '123 Main Street, Apartment 4B',
      city: 'Kuala Lumpur',
      state: 'Selangor',
      postcode: '50000',
    },
    items: [
      {
        id: '1',
        name: 'Wireless Bluetooth Headphones',
        image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=200&q=80',
        quantity: 1,
        price: 254.99,
      },
    ],
    timeline: [
      {
        status: 'Delivered',
        location: 'Delivered to customer',
        timestamp: '2024-01-23 14:30',
        completed: true,
      },
      {
        status: 'Out for Delivery',
        location: 'Package is out for delivery',
        timestamp: '2024-01-23 09:00',
        completed: true,
      },
      {
        status: 'Hub Arrived',
        location: 'Arrived at Kuala Lumpur Hub',
        timestamp: '2024-01-22 18:45',
        completed: true,
      },
      {
        status: 'Shipped',
        location: 'Package shipped from warehouse',
        timestamp: '2024-01-21 10:20',
        completed: true,
      },
      {
        status: 'Processing',
        location: 'Order confirmed and processing',
        timestamp: '2024-01-20 15:00',
        completed: true,
      },
    ],
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Button variant="ghost" onClick={() => navigate('/customer/orders')} className="mb-2">
            ← Back to Orders
          </Button>
          <h1 className="text-3xl font-bold">Order Details</h1>
          <p className="text-gray-600">Order #{order.id}</p>
        </div>
        <Badge className="bg-green-100 text-green-800 text-lg px-4 py-2">
          {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Order Items */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Order Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {order.items.map((item) => (
                  <div key={item.id} className="flex items-center gap-4">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-24 h-24 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <p className="font-semibold text-lg">{item.name}</p>
                      <p className="text-gray-600">Quantity: {item.quantity}</p>
                    </div>
                    <p className="text-xl font-bold text-orange-600">
                      RM {item.price.toFixed(2)}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Tracking Timeline */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Truck className="w-5 h-5" />
                Tracking Timeline
              </CardTitle>
              <p className="text-sm text-gray-600">Tracking Number: {order.trackingNumber}</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {order.timeline.map((event, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          event.completed ? 'bg-green-100' : 'bg-gray-100'
                        }`}
                      >
                        {event.completed ? (
                          <CheckCircle className="w-5 h-5 text-green-600" />
                        ) : (
                          <div className="w-3 h-3 rounded-full bg-gray-400" />
                        )}
                      </div>
                      {index < order.timeline.length - 1 && (
                        <div
                          className={`w-0.5 h-12 ${
                            event.completed ? 'bg-green-300' : 'bg-gray-300'
                          }`}
                        />
                      )}
                    </div>
                    <div className="flex-1 pb-8">
                      <p className="font-semibold">{event.status}</p>
                      <p className="text-sm text-gray-600">{event.location}</p>
                      <p className="text-xs text-gray-500 mt-1">{event.timestamp}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Order Summary & Details */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Subtotal</span>
                <span className="font-semibold">RM {order.subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Shipping</span>
                <span className="font-semibold">RM {order.shipping.toFixed(2)}</span>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Discount</span>
                  <span className="font-semibold">-RM {order.discount.toFixed(2)}</span>
                </div>
              )}
              <Separator />
              <div className="flex justify-between text-lg">
                <span className="font-semibold">Total</span>
                <span className="font-bold text-orange-600">RM {order.total.toFixed(2)}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Shipping Address
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1 text-sm">
                <p className="font-semibold">{order.shippingAddress.name}</p>
                <p className="text-gray-600">{order.shippingAddress.phone}</p>
                <p className="text-gray-600">{order.shippingAddress.address}</p>
                <p className="text-gray-600">
                  {order.shippingAddress.city}, {order.shippingAddress.state}{' '}
                  {order.shippingAddress.postcode}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5" />
                Payment Method
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm">{order.paymentMethod}</p>
              <Badge className="mt-2 bg-green-100 text-green-800">Paid</Badge>
            </CardContent>
          </Card>

          <div className="space-y-2">
            <Button className="w-full">Download Invoice</Button>
            <Button variant="outline" className="w-full">
              Contact Seller
            </Button>
            {order.status === 'delivered' && (
              <Button variant="outline" className="w-full">
                Write Review
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}