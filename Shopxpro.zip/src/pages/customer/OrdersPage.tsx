import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Package, Truck, CheckCircle, XCircle, Clock } from 'lucide-react';

export default function OrdersPage() {
  const [activeTab, setActiveTab] = useState('all');

  const orders = [
    {
      id: 'ORD-001',
      date: '2024-01-20',
      total: 299.99,
      status: 'delivered',
      trackingNumber: 'SHXMY123456',
      items: [
        {
          name: 'Wireless Bluetooth Headphones',
          image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=200&q=80',
          quantity: 1,
          price: 254.99,
        },
        {
          name: 'Phone Case',
          image: 'https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?w=200&q=80',
          quantity: 1,
          price: 45.00,
        },
      ],
    },
    {
      id: 'ORD-002',
      date: '2024-01-18',
      total: 149.50,
      status: 'shipped',
      trackingNumber: 'SHXMY789012',
      items: [
        {
          name: 'LEGO Building Blocks Set',
          image: 'https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=200&q=80',
          quantity: 1,
          price: 149.50,
        },
      ],
    },
    {
      id: 'ORD-003',
      date: '2024-01-15',
      total: 89.99,
      status: 'processing',
      trackingNumber: 'SHXMY345678',
      items: [
        {
          name: 'Classic Denim Jacket',
          image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=200&q=80',
          quantity: 1,
          price: 89.99,
        },
      ],
    },
    {
      id: 'ORD-004',
      date: '2024-01-10',
      total: 199.99,
      status: 'cancelled',
      trackingNumber: 'SHXMY901234',
      items: [
        {
          name: 'Smart Watch Pro',
          image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200&q=80',
          quantity: 1,
          price: 199.99,
        },
      ],
    },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'delivered':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'shipped':
        return <Truck className="w-5 h-5 text-blue-600" />;
      case 'processing':
        return <Clock className="w-5 h-5 text-orange-600" />;
      case 'cancelled':
        return <XCircle className="w-5 h-5 text-red-600" />;
      default:
        return <Package className="w-5 h-5 text-gray-600" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      delivered: 'bg-green-100 text-green-800',
      shipped: 'bg-blue-100 text-blue-800',
      processing: 'bg-orange-100 text-orange-800',
      cancelled: 'bg-red-100 text-red-800',
    };
    return (
      <Badge className={variants[status] || 'bg-gray-100 text-gray-800'}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const filteredOrders = orders.filter((order) => {
    if (activeTab === 'all') return true;
    return order.status === activeTab;
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">My Orders</h1>
        <p className="text-gray-600">Track and manage your orders</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">All Orders</TabsTrigger>
          <TabsTrigger value="processing">Processing</TabsTrigger>
          <TabsTrigger value="shipped">Shipped</TabsTrigger>
          <TabsTrigger value="delivered">Delivered</TabsTrigger>
          <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          <div className="space-y-4">
            {filteredOrders.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Package className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-xl font-semibold mb-2">No orders found</h3>
                  <p className="text-gray-600 mb-6">You haven't placed any orders yet</p>
                  <Button asChild>
                    <Link to="/products">Start Shopping</Link>
                  </Button>
                </CardContent>
              </Card>
            ) : (
              filteredOrders.map((order) => (
                <Card key={order.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {getStatusIcon(order.status)}
                        <div>
                          <CardTitle className="text-lg">{order.id}</CardTitle>
                          <p className="text-sm text-gray-600">Placed on {order.date}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        {getStatusBadge(order.status)}
                        <p className="text-sm text-gray-600 mt-1">
                          Tracking: {order.trackingNumber}
                        </p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {order.items.map((item, index) => (
                        <div key={index} className="flex items-center gap-4">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-20 h-20 object-cover rounded-lg"
                          />
                          <div className="flex-1">
                            <p className="font-semibold">{item.name}</p>
                            <p className="text-sm text-gray-600">Quantity: {item.quantity}</p>
                          </div>
                          <p className="font-semibold">RM {item.price.toFixed(2)}</p>
                        </div>
                      ))}
                      <div className="border-t pt-4 flex items-center justify-between">
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" asChild>
                            <Link to={`/customer/orders/${order.id}`}>View Details</Link>
                          </Button>
                          {order.status === 'delivered' && (
                            <Button variant="outline" size="sm">
                              Write Review
                            </Button>
                          )}
                          {order.status === 'processing' && (
                            <Button variant="outline" size="sm" className="text-red-600">
                              Cancel Order
                            </Button>
                          )}
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-600">Total</p>
                          <p className="text-xl font-bold text-orange-600">
                            RM {order.total.toFixed(2)}
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}