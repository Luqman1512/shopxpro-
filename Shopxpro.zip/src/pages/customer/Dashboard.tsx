import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuthStore } from '@/store';
import { Package, ShoppingCart, Heart, Wallet, TrendingUp } from 'lucide-react';

export default function CustomerDashboard() {
  const { user } = useAuthStore();

  const stats = [
    {
      title: 'Total Orders',
      value: '12',
      icon: Package,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      link: '/customer/orders',
    },
    {
      title: 'Pending Orders',
      value: '3',
      icon: ShoppingCart,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      link: '/customer/orders',
    },
    {
      title: 'Wishlist Items',
      value: '8',
      icon: Heart,
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      link: '/customer/wishlist',
    },
    {
      title: 'Wallet Balance',
      value: 'RM 250.00',
      icon: Wallet,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      link: '/customer/wallet',
    },
  ];

  const recentOrders = [
    {
      id: 'ORD-001',
      date: '2024-01-20',
      total: 299.99,
      status: 'Delivered',
      items: 2,
    },
    {
      id: 'ORD-002',
      date: '2024-01-18',
      total: 149.50,
      status: 'Shipped',
      items: 1,
    },
    {
      id: 'ORD-003',
      date: '2024-01-15',
      total: 89.99,
      status: 'Processing',
      items: 3,
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Welcome back, {user?.name}!</h1>
        <p className="text-gray-600">Here's what's happening with your account</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Link key={stat.title} to={stat.link}>
              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                      <p className="text-2xl font-bold">{stat.value}</p>
                    </div>
                    <div className={`${stat.bgColor} p-3 rounded-lg`}>
                      <Icon className={`w-6 h-6 ${stat.color}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>

      {/* Recent Orders */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Recent Orders</CardTitle>
            <Button variant="outline" size="sm" asChild>
              <Link to="/customer/orders">View All</Link>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentOrders.map((order) => (
              <div
                key={order.id}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50"
              >
                <div className="flex items-center gap-4">
                  <div className="bg-orange-50 p-3 rounded-lg">
                    <Package className="w-5 h-5 text-orange-600" />
                  </div>
                  <div>
                    <p className="font-semibold">{order.id}</p>
                    <p className="text-sm text-gray-600">{order.items} items • {order.date}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold">RM {order.total.toFixed(2)}</p>
                  <p className="text-sm text-gray-600">{order.status}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button variant="outline" className="h-auto py-4" asChild>
              <Link to="/products">
                <div className="text-center">
                  <ShoppingCart className="w-6 h-6 mx-auto mb-2" />
                  <p className="font-semibold">Browse Products</p>
                </div>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto py-4" asChild>
              <Link to="/customer/orders">
                <div className="text-center">
                  <Package className="w-6 h-6 mx-auto mb-2" />
                  <p className="font-semibold">Track Orders</p>
                </div>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto py-4" asChild>
              <Link to="/customer/wallet">
                <div className="text-center">
                  <Wallet className="w-6 h-6 mx-auto mb-2" />
                  <p className="font-semibold">Top Up Wallet</p>
                </div>
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}