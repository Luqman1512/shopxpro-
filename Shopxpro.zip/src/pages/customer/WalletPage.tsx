import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Wallet, Plus, ArrowUpRight, ArrowDownRight, CreditCard } from 'lucide-react';
import toast from 'react-hot-toast';

export default function WalletPage() {
  const [balance] = useState(250.00);
  const [topUpAmount, setTopUpAmount] = useState('');

  const transactions = [
    {
      id: 'TXN-001',
      type: 'topup',
      amount: 100.00,
      description: 'Wallet Top Up via FPX',
      date: '2024-01-20 14:30',
    },
    {
      id: 'TXN-002',
      type: 'payment',
      amount: -50.00,
      description: 'Payment for Order #ORD-001',
      date: '2024-01-18 10:15',
    },
    {
      id: 'TXN-003',
      type: 'refund',
      amount: 25.00,
      description: 'Refund for Order #ORD-002',
      date: '2024-01-15 16:45',
    },
    {
      id: 'TXN-004',
      type: 'topup',
      amount: 200.00,
      description: 'Wallet Top Up via Credit Card',
      date: '2024-01-10 09:20',
    },
    {
      id: 'TXN-005',
      type: 'payment',
      amount: -75.00,
      description: 'Payment for Order #ORD-003',
      date: '2024-01-08 11:30',
    },
  ];

  const handleTopUp = () => {
    const amount = parseFloat(topUpAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    if (amount < 10) {
      toast.error('Minimum top up amount is RM 10');
      return;
    }
    toast.success(`Top up of RM ${amount.toFixed(2)} initiated!`);
    setTopUpAmount('');
  };

  const quickAmounts = [50, 100, 200, 500];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">My Wallet</h1>
        <p className="text-gray-600">Manage your wallet balance and transactions</p>
      </div>

      {/* Balance Card */}
      <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
        <CardContent className="p-8">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-100 mb-2">Available Balance</p>
              <p className="text-4xl font-bold">RM {balance.toFixed(2)}</p>
            </div>
            <div className="bg-white/20 p-4 rounded-full">
              <Wallet className="w-8 h-8" />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top Up Section */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Top Up Wallet
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="amount">Enter Amount (RM)</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="0.00"
                  value={topUpAmount}
                  onChange={(e) => setTopUpAmount(e.target.value)}
                  min="10"
                  step="0.01"
                />
                <p className="text-xs text-gray-500 mt-1">Minimum: RM 10.00</p>
              </div>

              <div>
                <Label className="mb-2 block">Quick Amount</Label>
                <div className="grid grid-cols-2 gap-2">
                  {quickAmounts.map((amount) => (
                    <Button
                      key={amount}
                      variant="outline"
                      size="sm"
                      onClick={() => setTopUpAmount(amount.toString())}
                    >
                      RM {amount}
                    </Button>
                  ))}
                </div>
              </div>

              <Button className="w-full" onClick={handleTopUp}>
                <CreditCard className="w-4 h-4 mr-2" />
                Top Up Now
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Transaction History */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Transaction History</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="all">
                <TabsList>
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="topup">Top Up</TabsTrigger>
                  <TabsTrigger value="payment">Payment</TabsTrigger>
                  <TabsTrigger value="refund">Refund</TabsTrigger>
                </TabsList>

                <TabsContent value="all" className="mt-4">
                  <div className="space-y-3">
                    {transactions.map((txn) => (
                      <div
                        key={txn.id}
                        className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50"
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`p-2 rounded-full ${
                              txn.type === 'topup'
                                ? 'bg-green-100'
                                : txn.type === 'refund'
                                ? 'bg-blue-100'
                                : 'bg-orange-100'
                            }`}
                          >
                            {txn.type === 'topup' || txn.type === 'refund' ? (
                              <ArrowDownRight
                                className={`w-5 h-5 ${
                                  txn.type === 'topup' ? 'text-green-600' : 'text-blue-600'
                                }`}
                              />
                            ) : (
                              <ArrowUpRight className="w-5 h-5 text-orange-600" />
                            )}
                          </div>
                          <div>
                            <p className="font-semibold">{txn.description}</p>
                            <p className="text-sm text-gray-500">{txn.date}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p
                            className={`text-lg font-bold ${
                              txn.amount > 0 ? 'text-green-600' : 'text-red-600'
                            }`}
                          >
                            {txn.amount > 0 ? '+' : ''}RM {Math.abs(txn.amount).toFixed(2)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="topup" className="mt-4">
                  <div className="space-y-3">
                    {transactions
                      .filter((txn) => txn.type === 'topup')
                      .map((txn) => (
                        <div
                          key={txn.id}
                          className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
                        >
                          <div className="flex items-center gap-3">
                            <div className="p-2 rounded-full bg-green-100">
                              <ArrowDownRight className="w-5 h-5 text-green-600" />
                            </div>
                            <div>
                              <p className="font-semibold">{txn.description}</p>
                              <p className="text-sm text-gray-500">{txn.date}</p>
                            </div>
                          </div>
                          <p className="text-lg font-bold text-green-600">
                            +RM {txn.amount.toFixed(2)}
                          </p>
                        </div>
                      ))}
                  </div>
                </TabsContent>

                <TabsContent value="payment" className="mt-4">
                  <div className="space-y-3">
                    {transactions
                      .filter((txn) => txn.type === 'payment')
                      .map((txn) => (
                        <div
                          key={txn.id}
                          className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
                        >
                          <div className="flex items-center gap-3">
                            <div className="p-2 rounded-full bg-orange-100">
                              <ArrowUpRight className="w-5 h-5 text-orange-600" />
                            </div>
                            <div>
                              <p className="font-semibold">{txn.description}</p>
                              <p className="text-sm text-gray-500">{txn.date}</p>
                            </div>
                          </div>
                          <p className="text-lg font-bold text-red-600">
                            RM {Math.abs(txn.amount).toFixed(2)}
                          </p>
                        </div>
                      ))}
                  </div>
                </TabsContent>

                <TabsContent value="refund" className="mt-4">
                  <div className="space-y-3">
                    {transactions
                      .filter((txn) => txn.type === 'refund')
                      .map((txn) => (
                        <div
                          key={txn.id}
                          className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
                        >
                          <div className="flex items-center gap-3">
                            <div className="p-2 rounded-full bg-blue-100">
                              <ArrowDownRight className="w-5 h-5 text-blue-600" />
                            </div>
                            <div>
                              <p className="font-semibold">{txn.description}</p>
                              <p className="text-sm text-gray-500">{txn.date}</p>
                            </div>
                          </div>
                          <p className="text-lg font-bold text-green-600">
                            +RM {txn.amount.toFixed(2)}
                          </p>
                        </div>
                      ))}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}