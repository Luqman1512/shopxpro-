# SHOPX PRO - E-Commerce Marketplace

A full-featured e-commerce marketplace platform supporting multiple user roles (Customer, Seller, Admin) with comprehensive shopping, selling, and administrative capabilities.

## Features

- **Customer Features**: Browse products, shopping cart, checkout, order tracking, wishlist, digital wallet
- **Seller Features**: Dashboard with analytics, product management, order processing, shop customization
- **Admin Features**: Platform analytics, user management, category management, global vouchers

## Tech Stack

- React + TypeScript
- TailwindCSS + ShadCN UI
- Zustand (State Management)
- React Router v6

## Getting Started

```bash
npm install
npm run dev
```

## Demo Accounts

- Customer: customer1@shopx.com
- Seller: seller1@shopx.com
- Admin: admin@shopx.com

If you are developing a production application, we recommend updating the configuration to enable type aware lint rules:

- Configure the top-level `parserOptions` property like this:

```js
export default {
  // other rules...
  parserOptions: {
    ecmaVersion: 'latest',
    sourceType: 'module',
    project: ['./tsconfig.json', './tsconfig.node.json'],
    tsconfigRootDir: __dirname,
  },
}
```

- Replace `plugin:@typescript-eslint/recommended` to `plugin:@typescript-eslint/recommended-type-checked` or `plugin:@typescript-eslint/strict-type-checked`
- Optionally add `plugin:@typescript-eslint/stylistic-type-checked`
- Install [eslint-plugin-react](https://github.com/jsx-eslint/eslint-plugin-react) and add `plugin:react/recommended` & `plugin:react/jsx-runtime` to the `extends` list
